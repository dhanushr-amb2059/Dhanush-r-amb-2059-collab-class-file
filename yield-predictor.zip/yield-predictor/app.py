import sys
import pandas as pd
import requests
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QLineEdit,
    QScrollArea
)
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor

# ---------------- LOAD DATA ----------------
data = pd.read_csv("Crop_recommendation.csv")

X = data.drop("label", axis=1)
y = data["label"]

# ---------------- TRAIN CROP MODEL ----------------
crop_model = RandomForestClassifier()
crop_model.fit(X, y)

# ---------------- CREATE YIELD TARGET ----------------
data["yield_score"] = (
    data["temperature"] * 0.3 +
    data["humidity"] * 0.2 +
    data["rainfall"] * 0.5
)

X_yield = data.drop(["label", "yield_score"], axis=1)
y_yield = data["yield_score"]

yield_model = RandomForestRegressor()
yield_model.fit(X_yield, y_yield)

# ---------------- API ----------------
API_KEY = "4800f256e7ec5bb6edb3cbe2d634ee2a"

def get_weather(city):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    res = requests.get(url).json()

    temp = res["main"]["temp"]
    humidity = res["main"]["humidity"]
    rainfall = res.get("rain", {}).get("1h", 5) * 10

    return temp, humidity, rainfall

# ---------------- SOIL ----------------
def get_soil_from_dataset():
    sample = data.sample(1)
    return (
        sample["N"].values[0],
        sample["P"].values[0],
        sample["K"].values[0],
        sample["ph"].values[0]
    )

# ---------------- CROP INFO ----------------
def crop_info(crop):
    info = {
        "rice": ("June-July", "Sep-Oct"),
        "wheat": ("Oct-Nov", "Mar-Apr"),
        "maize": ("Jun-Jul", "Sep-Oct"),
        "cotton": ("Apr-May", "Sep-Oct"),
        "sugarcane": ("Jan-Mar", "12 months"),
        "coffee": ("Jun-Jul", "Nov-Dec")
    }
    return info.get(crop, ("Varies", "Varies"))

# ---------------- UI ----------------
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

class App(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("AI Agriculture Assistant 🌾")
        self.setGeometry(300, 150, 520, 450)
        self.setStyleSheet("background-color: #eef2f7;")

        layout = QVBoxLayout()
        layout.setContentsMargins(30, 20, 30, 20)
        layout.setSpacing(15)

        # Title
        self.title = QLabel("🌾 AI Crop Recommendation")
        self.title.setFont(QFont("Segoe UI", 18, QFont.Bold))
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("color: #1e272e;")

        # Input
        self.input = QLineEdit()
        self.input.setPlaceholderText("Enter city (e.g., Bangalore)")
        self.input.setFixedHeight(40)
        self.input.setText("Bangalore")  # default value
        self.input.returnPressed.connect(self.predict)  # Enter key support
        self.input.setStyleSheet("""
            QLineEdit {
                background: white;
                border: 2px solid #dcdde1;
                border-radius: 10px;
                padding-left: 12px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border-color: #27ae60;
            }
        """)

        # Button
        self.button = QPushButton("Get Recommendation")
        self.button.setFixedHeight(42)
        self.button.setCursor(Qt.PointingHandCursor)
        self.button.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                font-size: 15px;
                font-weight: bold;
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #219150;
            }
        """)
        self.button.clicked.connect(self.predict)

        # ---------------- SCROLLABLE RESULT ----------------
        self.result = QLabel()
        self.result.setWordWrap(True)
        self.result.setAlignment(Qt.AlignTop)
        self.result.setStyleSheet("""
            QLabel {
                background-color: white;
                border-radius: 15px;
                padding: 20px;
                font-size: 14px;
                color: #2d3436;
            }
        """)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setWidget(self.result)
        self.scroll.setMinimumHeight(250)
        self.scroll.setStyleSheet("""
            QScrollArea {
                border: 1px solid #dfe6e9;
                border-radius: 15px;
                background: white;
            }
        """)

        # Add widgets
        layout.addWidget(self.title)
        layout.addWidget(self.input)
        layout.addWidget(self.button)
        layout.addWidget(self.scroll)

        self.setLayout(layout)

    def predict(self):
        city = self.input.text()

        try:
            temp, humidity, rainfall = get_weather(city)
            N, P, K, ph = get_soil_from_dataset()

            input_data = pd.DataFrame([{
                "N": N,
                "P": P,
                "K": K,
                "temperature": temp,
                "humidity": humidity,
                "ph": ph,
                "rainfall": rainfall
            }])

            crop = crop_model.predict(input_data)[0]
            yield_value = yield_model.predict(input_data)[0]
            yield_percent = round((yield_value / data["yield_score"].max()) * 100, 2)

            sow, harvest = crop_info(crop)

            self.result.setText(f"""
                <div style="font-size:16px;">
                    <b>🌾 Recommended Crop:</b> {crop}<br><br>

                    <b>📊 Yield:</b> {yield_percent}%<br>
                    <b>🌱 Sowing:</b> {sow}<br>
                    <b>🌾 Harvest:</b> {harvest}<br><br>

                    <hr>

                    <b>🌡 Temperature:</b> {temp}°C<br>
                    <b>💧 Humidity:</b> {humidity}%<br>
                    <b>🌧 Rainfall:</b> {rainfall} mm
                </div>
            """)

        except:
            self.result.setText("❌ Error: Check city or API key")

# ---------------- RUN ----------------
app = QApplication(sys.argv)
window = App()
window.show()
sys.exit(app.exec_())